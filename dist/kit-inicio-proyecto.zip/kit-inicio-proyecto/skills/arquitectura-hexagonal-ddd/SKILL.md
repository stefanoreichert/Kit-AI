---
name: arquitectura-hexagonal-ddd
description: Diseñar, implementar y revisar arquitectura hexagonal con DDD en el proyecto, definiendo contextos, puertos, casos de uso y adaptadores según el stack confirmado. Usar para decisiones de arquitectura o trabajo de código autorizado; no selecciona tecnologías ni inicia funcionalidades por sí sola.
---

# Arquitectura hexagonal y DDD

Leer instrucciones aplicables y las secciones de ficha, arquitectura, decisiones y contratos afectadas por la tarea. Aplicar el recorrido pertinente de [planificación](../plan-maestro-desarrollo-sistema/references/flujo-de-trabajo.md), sin repetir preparación al ejecutar o retomar. Confirmar stack pendiente antes de elegir perfil: [Laravel](references/laravel.md), [Flutter](references/flutter.md) o [Go](references/go.md); cargar solo los pertinentes. Para otro stack, documentar su adaptación sin copiar convenciones ajenas. Un sistema puede combinar perfiles sin compartir detalles de sus adaptadores.

## Preparar la arquitectura

- Usar `/src` en la raíz del repositorio para el código propio, siempre salvo elección explícita del usuario. Registrar la raíz efectiva en `.agents/project.json`, ficha y arquitectura; una excepción necesita solicitud y fecha en decisiones. Ni un perfil ni las convenciones existentes autorizan cambiarla. Base: `src/<Contexto>/{Domain,Application,Infrastructure,UI}`; adaptar nombres/empaquetado internos al lenguaje conservando src. No reemplazarla por `app/Contexts`, `app/Domain`, `lib/src` o `internal` en la raíz. Los archivos técnicos de arranque/composición que el framework exija pueden quedar fuera, sin reglas de negocio.
- Partir de actores, lenguaje, procesos, invariantes y propiedad de datos. Derivar contextos de esas reglas; no crearlos por cada pantalla ni suponer microservicios.
- Organizar por contexto y, dentro, Domain, Application, Infrastructure y UI/Presentation. La dirección de dependencias apunta al núcleo; la composición conecta adaptadores con puertos.
- Domain contiene entidades, agregados, value objects, invariantes, servicios y eventos sin frameworks, ORM, HTTP o SDKs. Application coordina casos de uso y depende de contratos del núcleo, nunca de Infrastructure/UI ni de servicios globales del framework.
- Ubicar los puertos donde el núcleo los necesita: repositorios y capacidades del dominio en Domain; reloj, transacciones, identidad, comunicación u otras necesidades de orquestación en Application cuando esa sea su responsabilidad. No forzar interfaces ajenas al problema ni permitir que un adaptador defina la política.
- UI valida formato y traduce entrada/salida. Las escrituras y decisiones de negocio pasan por Application; los modelos ORM y componentes de pantalla no las implementan. Las consultas usan contratos de lectura cuando corresponda, sin esconder reglas en closures de UI.
- Los contextos se comunican con contratos publicados, no mediante tablas, modelos, casos de uso internos o implementaciones de otro contexto. La orquestación usa esos contratos y adaptadores explícitos. SharedKernel se limita a conceptos realmente compartidos con propietario y semántica común.
- Precisar límites transaccionales y concurrentes desde las invariantes. No considerar atómica una llamada externa junto a una transacción local. Elegir idempotencia, outbox, reintentos o compensación según el recorrido; no imponer CQRS, event sourcing o un bus por defecto.

Registrar cambios materiales en decisiones según el flujo y su plantilla; una modificación rutinaria no requiere una nueva decisión. Mantener incógnitas pendientes, conservar fuentes y autorizaciones; los ejemplos de otro proyecto no son requisitos.

## Modelado de Domain

Exigir los elementos que correspondan al modelo de negocio:

- **Entidad:** cuando el concepto conserva identidad y tiene ciclo de vida o comportamiento. Su estado cambia mediante operaciones que protegen invariantes, no por escrituras arbitrarias de la UI/ORM.
- **Value object:** cuando representa un concepto definido por su valor, igualdad y restricciones propias. Encapsular validación semántica y conservar inmutabilidad; no sustituirlo por un string/DTO si eso dispersa invariantes.
- **Agregado y raíz:** cuando hay un límite de consistencia que debe proteger invariantes al modificar entidades/valores. Precisar su frontera y punto de entrada; no agrupar todos los modelos ni crear contenedores sin una razón de negocio.
- **Servicios/eventos de dominio:** para políticas que no pertenecen naturalmente a una entidad/valor y hechos del negocio necesarios para sus recorridos, respectivamente. No generar uno por cada operación CRUD por rutina.

No exigir todas las categorías en cada contexto ni crear clases vacías para cumplir carpetas. Tampoco omitir entidades, valores o agregados necesarios para reducir tokens: documentar qué concepto/invariante justificó su elección y probar su comportamiento. Los DTOs de transporte no sustituyen el modelo; las reglas no se trasladan a Eloquent, controladores, componentes o adaptadores.

## Aplicar a trabajo autorizado

Consultar la tarea y sus dependencias mediante roadmap; el flujo define autorización, estados y evidencia. Preparar src con `.gitkeep` no autoriza frameworks, contextos ficticios ni funcionalidades.

Modelar invariantes en el dominio; comprobar permisos e identidad/tenant en límites y casos de uso con contratos confiables. Tratar errores externos mediante contratos de error del núcleo; el adaptador los traduce. Registrar datos necesarios sin secretos ni cuerpos completos con información personal. La UI ofrece errores comprensibles y conserva los detalles técnicos en la observabilidad apropiada.

Aplicar la estrategia de pruebas del flujo a las invariantes, casos de uso, contratos y adaptadores afectados. Un chequeo de imports es estructural; no demuestra aislamiento, reglas correctas ni una integración operativa.

En un repositorio existente, identificar los desvíos concretos y proponer cortes de refactorización con alcance. Una ubicación heredada fuera de src se registra como desvío, no como excepción confirmada; no agregar contextos de negocio allí ni migrar toda la aplicación sin un pedido que lo cubra. No atribuir pureza de dominio a una estructura de carpetas: revisar imports, herencia, tipos y dependencias de Domain/Application, y adaptar autoload/composición para cargar src.
